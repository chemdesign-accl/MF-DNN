import MDAnalysis as mda
from MDAnalysis.lib.distances import distance_array
import numpy as np
from collections import defaultdict

# Constants
topology_file = "3429_complex.prmtop"
trajectory_files = ["./R1/sim.dcd","./R2/3429_pose_1_R1.nc", "./R3/3429_pose_1_R1.nc"]
cutoff = 3.5  # Å
output_file = "ligand_contact_occupancy_combined.txt"

# Initialize counters
contact_counts = defaultdict(int)
total_frames = 0

# Loop over each replica
for traj_file in trajectory_files:
    u = mda.Universe(topology_file, traj_file)
    ligand = u.select_atoms("resname LIG")
    protein = u.select_atoms("protein")
    
    for ts in u.trajectory:
        total_frames += 1
        nearby_residues = set()
        for residue in protein.residues:
            residue_atoms = residue.atoms
            dists = distance_array(ligand.positions, residue_atoms.positions)
            if np.any(dists < cutoff):
                nearby_residues.add(residue.resid)
        for resid in nearby_residues:
            contact_counts[resid] += 1

# Write results
with open(output_file, "w") as f:
    f.write(f"{'Resid':>8}  {'Occupancy (%)':>15}\n")
    for resid, count in sorted(contact_counts.items()):
        occupancy = (count / total_frames) * 100
        f.write(f"{resid:8}  {occupancy:15.2f}\n")

print(f"Combined contact occupancy written to '{output_file}'")

